from django.shortcuts import render
from django.http import JsonResponse
from .models import cliente
from ..project.Serializers import cliente_serializer
import json


# Create your views here.
