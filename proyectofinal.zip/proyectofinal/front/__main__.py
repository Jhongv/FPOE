from views.menusecundario import Menu2

class Main():
    def main():
        app = Menu2()
    main()